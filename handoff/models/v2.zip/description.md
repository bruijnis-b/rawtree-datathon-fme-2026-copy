# Model v2

IVAN experiment `exp-0214`, git `a8fb90c`, fine-tuned from `embed-cmp/1`.

**v2** (Sun 01:30): the phase C configuration and recipe, fine-tuned on live snapshot 1 (practice stream up to Sat 21:00 UTC); the final model (06:30) is the same recipe on all history and snapshot 2. History configuration `c_a4_25` with a 100-event history (chosen on the live hold-out over 3 folds × 2 seeds). Fine-tuning: 2 epochs, 50 % history batches, lr 0.3×, practice products hide their ID half the time, **new users trained on short histories** (their history truncated to 0–20 events at random), no carousel-feedback task. **Serving rule:** a user history shorter than 5 events is ignored (1–3 events score worse than none).

**Not in the model, for Bas's layer** (cold analysis): drop products the user already bought; boost products in the user's open cart (carted, not bought since). Built into the embedding, the open cart lowered the score on our held-out carousels, so it belongs in the correction layer as one fitted weight.

## In one paragraph

A two-tower recommender. One tower turns a product into a vector of 64 numbers, the other turns a shopper's request into a vector of the same size; the score of a product is how well the two line up (dot product) plus a per-product bias. The score is calibrated as the **log-odds that the shopper buys the product when it is shown in slot 1**, so corrections (discount, trend) can be added to it. It was trained on the 60-day history and then fine-tuned on the live practice stream, so it has seen today's new users and new products.

## What it embeds

**Product tower** (no request input, so product vectors are computed once):

- category, subcategory and brand: learned vectors;
- reference price (the product's original price, never the current one): its log, and its log minus the subcategory's mean log price;
- description: a bag of words (hashed into 4,096 buckets, averaged);
- a learned vector per known product (its identity), hidden in training 40% of the time so the content path also learns to score a product alone; during fine-tuning the practice-round products hid theirs 50% of the time;
- a bias from the content (expected popularity), plus a learned offset for products without an identity vector (every new product at serving time).

**User tower** (from the request, plus the user's history if known):

- device, region, page, hour of day: learned vectors;
- `recent_views` (up to 6 products from the request): their product vectors, pooled by a recency-weighted mean (the newest view counts most, each step back × 0.7);
- long-term history: the product vectors of the user's last 100 events (views 1×, add-to-carts 2×, purchases 4×), averaged; dropped entirely in 30% of training examples so the model also works without it. Known users' history vectors are precomputed in `user_vectors.npz` (74,174 users); live events can be passed with `score(..., events=...)`.
- `is_new_user`: an input whose weights start at zero; learned during the live fine-tuning.
- no per-user identity vector: a user is described only by what they do.

## How it was trained, and why

- **Two tasks on shared towers.** (1) Carousel: did the shopper click each of the 10 shown products, and buy after clicking. (2) Organic: which product did the shopper view, add to cart or buy next on the site (weight 1.0; purchases sampled 6× as often as views), against the other products in the batch, corrected for popularity (logQ). The organic task covers the whole catalogue, where the old carousel only shows a few products; without it the model is much worse.
- **Old-carousel bias removed.** A slot term (attention by slot and device) is learned in the click head and dropped at serving; products shown only by the old policy's choice are not treated as negatives elsewhere.
- Settings: dimension 64, hidden layer 128, click weight 0.3, learning rate 0.001, weight decay 0.0, batch 2048, 15 epochs, trained on fold 0 (10 % of users and 300 products held out to test cold start).
- **Live fine-tuning:** 2 epochs over the live organic events (live dataset v1), 50% of each batch from the history to avoid forgetting, learning rate 0.3× the history rate, weights trained: all, carousel feedback task off (with a live hold-out: 20 % of live users, the last 2 hours, 60 practice products).
- **Recalibration:** the final score is `0.973 · score +0.118`, fitted on half of the history validation week and checked on the other half (applied inside the scorer).

## Strong points (measured)

Lifts are relative to best sellers on the same requests (+2.0 = 3× best sellers), with 95 % intervals.

| Measure | All | Cold | New users | New products |
|---|---|---|---|---|
| History: ips_hit@10 (carousel, propensity-weighted) | +4.24 [+3.93, +4.56] | +4.21 [+3.58, +4.95] | +3.03 [+2.37, +3.85] | +5.10 [+4.07, +6.36] |
| History: organic recall@10 | +2.74 [+2.55, +2.93] | +3.12 [+2.62, +3.69] | +1.53 [+1.18, +1.96] | +6.51 [+4.94, +8.54] |
| Live hold-out: organic recall@10 | +2.45 [+2.31, +2.60] | +2.30 [+2.10, +2.53] | +2.52 [+2.28, +2.78] | +1.85 [+1.57, +2.17] |

- within a shown carousel, the clicked product scores above another shown product 78% of the time (slate_auc; 50 % = random).
- held-out practice products get 1.04% of top-10 slots against 1.15% of purchases.
- calibration: predicted and observed purchase rates differ by at most 18% per score decile.
- serving: 0.28 ms per request (p99, numpy only).
- new users: lift 2.09 without history, 2.85 when their last 50 live events are passed.

## Weak points and what it does not do

- Discounts are not in the model (it only sees the original price): the discount effect (+60 % purchases for a 20 % discount) belongs in the correction layer.
- Trends of the final round are not in the model: the history has none, and live trends are left out on purpose.
- Stock, already-bought and diversity are not handled: hard filters in recsys.
- A user's history is frozen at export time unless live events are passed with `events=`.

## Use

```python
from training.export.scorer import load
model = load("models/v2")
pm = model.embed_products(rows)      # rows: product_id, category, subcategory, brand, description, price (ORIGINAL)
scores = model.score(request, pm)  # one per product, in pm.ids order; optional events=[(product_id, event_type), ...]
```
